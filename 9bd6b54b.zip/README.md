# Política de Privacidade

Este pacote contém os arquivos para publicar a política de privacidade do app Gestão de Gastos.

## Arquivos
- index.html
- politica_privacidade_gestao_de_gastos.html

## Publicação no GitHub Pages
1. Faça upload dos arquivos para o repositório.
2. Certifique-se de que o `index.html` esteja na raiz.
3. Ative o GitHub Pages nas configurações do repositório.
4. Copie a URL pública gerada e use no Google Play Console.
